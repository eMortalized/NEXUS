app.controller('aboutController', ['$scope', function($scope) {
	$scope.pageClass = 'page-about';
}]);