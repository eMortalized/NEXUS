ngView-animation-effects
========================

This is a simple demonstration of how easy you can make your ngView directive transition pages with nice animations. All you need to do is set up necessary CSS rules!

Hope this mini-project was useful for you! If you have any question or ideas for new animations, feel free to contact me or submit pull request.

Check it in [action][1]!

Thank you for stopping by!

[1]: http://dfsq.github.io/ngView-animation-effects/app
